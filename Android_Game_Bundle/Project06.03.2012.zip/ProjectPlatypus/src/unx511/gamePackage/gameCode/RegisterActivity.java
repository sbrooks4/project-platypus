/*
* Copyright (c) 2012 Project Platypus Open Source Team Seneca College
*
*  Licensed under the Apache License, Version 2.0 (the "License");
*  you may not use this file except in compliance with the License.
*  You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
*  Unless required by applicable law or agreed to in writing, software
*  distributed under the License is distributed on an "AS IS" BASIS,
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*  See the License for the specific language governing permissions and
*  limitations under the License.
*/

package unx511.gamePackage.gameCode;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** 
 * This activity is the registration Activity for the game that allows
 * new players login access to the game.
 * 
 * @author Stephen Brooks 
 * @extends Activity
 */
@SuppressWarnings("unused") // remove this annotation after unused imports have been deleted or used (preferably near project completion)
public class RegisterActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
   
        final Button submit_button = (Button) findViewById(R.id.regSubmitBtn);
    
        // Event Handler for the Submit Button
        submit_button.setOnClickListener(new View.OnClickListener() {
	       public void onClick(View v) {
	    	   
	    	 if (validateRegistration()){  
               Toast.makeText(RegisterActivity.this,"Registration successful",Toast.LENGTH_SHORT).show();  
	   	       //startActivity(new Intent(v.getContext(), LoginActivity.class));
	    	 }
	    	 else{
	           Toast.makeText(RegisterActivity.this,"Registration failed",Toast.LENGTH_SHORT).show(); 
	    	 }
	       }
        });
    }
    
    /**
     * This method validates user registration after the submit button has been clicked
     * and returns true if valid data was entered false otherwise. 
     * 
     * @return isValid
     */
    public boolean validateRegistration() {
    	
    	// This method is still under construction
    	
    	Boolean isValid = false;
    	
    	/*
    	
        final EditText pass1 = (EditText) findViewById(R.id.password1); 
        final EditText pass2 = (EditText) findViewById(R.id.password2);
        final EditText ip = (EditText) findViewById(R.id.ipAddress);
        String ipStr = "";
        String errors = "";
        
        
    	
        // convert the EditText ip address to a string
         ipStr = ip.toString();
        
      	   // check to see if IP Address has been entered
           if (!ipStr.matches("")){
    	     // figure out how to validate this one properly. Most regex examples are bad.
    	     isValid = true;
           }
           else{
        	   
        	  errors.concat("IP Address is Invalid\n");
           
           }
        
        if (pass1.toString().equals(pass2.toString())){
           isValid = true;
        }
        
        */
           
    	return isValid;
    }
    
} // end of RegisterActivity Activity

